<?php

function dd(...$var)
{
	dump(...$var);
	die;
}
